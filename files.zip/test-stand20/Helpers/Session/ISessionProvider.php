<?php
namespace Session;

interface ISessionProvider extends IStartStop, IBaseSessionProvider {
	
}

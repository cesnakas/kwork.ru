<?php declare(strict_types=1);

namespace Exception;

/**
 * Class NeighborNotFoundException
 * @package Exception
 */
final class NeighborNotFoundException extends \Exception {

}
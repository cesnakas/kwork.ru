<?php


namespace Exception;

/**
 * Ошибка валидации данных при сохранении кворка
 *
 * @package Exception
 */
class KworkSaveValidatorException extends \RuntimeException {

}
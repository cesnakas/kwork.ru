<?php

if (function_exists('xhprof_enable') && false) {
	xhprof_enable(XHPROF_FLAGS_CPU + XHPROF_FLAGS_MEMORY);
}


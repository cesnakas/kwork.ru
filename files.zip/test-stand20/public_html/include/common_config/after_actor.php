<?php

// config
{
	/*$rsc = $conn->execute("SELECT * from config");
	foreach ($rsc->getrows() as $data) {
		Configurator::getInstance()->set($data["setting"], $data["value"]);
	}*/
}
